import math

def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between two points on the Earth"""
    R = 6371  # Earth's radius in kilometers
    
    # Convert coordinates to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Calculate differences
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    
    # Haversine formula
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    return R * c

def dijkstra(source, destination, places):
    """Find the shortest path using Dijkstra's algorithm"""
    # Initialize distances and previous nodes
    distances = {place: float('infinity') for place in places}
    previous = {place: None for place in places}
    distances[source] = 0
    
    # Priority queue (using a list for simplicity)
    unvisited = set(places.keys())
    
    while unvisited:
        # Find the unvisited node with the smallest distance
        current = min(unvisited, key=lambda x: distances[x])
        unvisited.remove(current)
        
        # If we've reached the destination, reconstruct the path
        if current == destination:
            path = []
            while current is not None:
                path.append(current)
                current = previous[current]
            return path[::-1]  # Reverse to get source to destination
        
        # Update distances to neighbors
        for neighbor in places:
            if neighbor != current and neighbor in unvisited:
                # Calculate distance between current and neighbor
                lat1, lon1 = places[current]
                lat2, lon2 = places[neighbor]
                distance = haversine(lat1, lon1, lat2, lon2)
                
                # Update if we found a shorter path
                if distances[current] + distance < distances[neighbor]:
                    distances[neighbor] = distances[current] + distance
                    previous[neighbor] = current
    
    return []  # No path found
