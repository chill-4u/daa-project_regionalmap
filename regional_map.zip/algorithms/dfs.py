from .dijkstras import haversine

def dfs(source, destination, places):
    """Find a path using Depth-First Search"""
    if source not in places or destination not in places:
        return []
        
    # Initialize stack with source node
    stack = [(source, [source])]
    visited = set([source])
    
    while stack:
        current, path = stack.pop()
        
        # If we've reached the destination, return the path
        if current == destination:
            return path
            
        # Explore all neighbors
        for neighbor in places:
            if neighbor != current and neighbor not in visited:
                visited.add(neighbor)
                stack.append((neighbor, path + [neighbor]))
    
    return []  # No path found
