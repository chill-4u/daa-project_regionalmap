import requests
import json

# Test the path finding API
def test_path_finding(source, destination, method):
    url = 'http://127.0.0.1:5000/find-path'
    data = {
        'source': source,
        'destination': destination,
        'method': method
    }
    
    try:
        response = requests.post(url, json=data)
        if response.status_code == 200:
            result = response.json()
            print("\nPath Finding Results:")
            print(f"Source: {source}")
            print(f"Destination: {destination}")
            print(f"Method: {method}")
            print(f"Path: {result['path']}")
            print(f"Total Distance: {result['distance']} km")
            print(f"Estimated Time: {result['time']} minutes")
            print(f"Traffic Level: {result['traffic']}")
            print(f"Nearby Accidents: {result['accidents']}")
        else:
            print(f"Error: {response.status_code}")
            print(response.text)
    except Exception as e:
        print(f"Error: {str(e)}")

# Test cases
print("Testing Regional Mapping API...")
print("\nTest 1: Delhi to Mumbai using Dijkstra's algorithm")
test_path_finding("Delhi", "Mumbai", "dijkstra")

print("\nTest 2: Bangalore to Chennai using BFS")
test_path_finding("Bangalore", "Chennai", "bfs")

print("\nTest 3: Kolkata to Hyderabad using DFS")
test_path_finding("Kolkata", "Hyderabad", "dfs") 